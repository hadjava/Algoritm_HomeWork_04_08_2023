//Постройте частотный словарь букв русского (или английского) алфавита.
  //      * для решения можно использовать Array или HashMap ( на ваше усмотрение)..


import java.util.HashMap;
import java.util.Map;

public class FrequencyDictionary {
    public static void main(String[] args) {
        // Создаем частотный словарь для букв русского алфавита
        Map<Character, Integer> frequencyMap = new HashMap<>();

        // Заполняем частотный словарь буквами русского алфавита
        for (char ch = 'а'; ch <= 'я'; ch++) {
            frequencyMap.put(ch, 0);
        }

        // Пример текста для анализа
        String text = "Пример текста для анализа";

        // Приводим текст к нижнему регистру, чтобы учитывать и большие, и маленькие буквы
        text = text.toLowerCase();

        // Анализируем текст и обновляем частотный словарь
        for (char ch : text.toCharArray()) {
            if (frequencyMap.containsKey(ch)) {
                frequencyMap.put(ch, frequencyMap.get(ch) + 1);
            }
        }

        // Выводим результаты
        for (Map.Entry<Character, Integer> entry : frequencyMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}